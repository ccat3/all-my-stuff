Maps by Jackathan for ValveNewsNetwork "Black Mesa's Xen: Massive Leak" video

Place these files in \steamapps\common\Black Mesa\bms\maps\

Then use the developer console to load them